from CvPythonExtensions import *
import CvUtil
gc = CyGlobalContext()

# Example Update file
